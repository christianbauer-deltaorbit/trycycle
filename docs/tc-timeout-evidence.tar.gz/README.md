# trycycle Timeout Evidence — Meshing-Module Session, 2026-04-23

Four consecutive `planning-initial` dispatches failed across both trycycle modes
with distinct error messages. Summary:

| # | Mode              | Duration | Failure                                              |
|---|-------------------|----------|------------------------------------------------------|
| 1 | fallback-runner   | ~1 min   | `You've hit your limit · resets 11am (UTC)` (rate)   |
| 2 | native Agent      | 6 min    | `API Error: Stream idle timeout - partial response`  |
| 3 | native Agent      | 30 min   | `Request timed out`                                  |
| 4 | fallback-runner   | unknown  | `API Error: Stream idle timeout - partial response`  |

Key finding from attempt 4: the fallback-runner spawns its own `claude` subprocess
with a separate API connection, yet still hit the stream-idle timeout. That locates
the timeout at the Anthropic streaming-API layer, below Claude Code's Agent tool
and below the fallback runner's subprocess boundary.

## Layout

- `rendered-prompt.txt` — the full rendered planning-initial prompt (~311 KB)
  that all four attempts received. Built by
  `run_phase.py prepare --phase planning-initial` against the meshing-module
  workspace with the approved test-strategy as context.
- `attempt-1-fallback-ratelimit/` — reply, result.json, stderr from dispatch 1.
- `attempt-2-native-stream-idle.txt` — notification-only evidence from Agent
  dispatch 2 (no reply file available from native mode).
- `attempt-3-native-request-timeout.txt` — notification-only from Agent
  dispatch 3.
- `attempt-4-fallback-stream-idle/` — reply, result.json, stderr from
  dispatch 4 (the critical one — runner did NOT escape the timeout).

## Context for the fix

The trycycle fork being modified:
- Just landed `41d639e` (reject SKILL.md as template) and `862cad8` (greedy
  ignored-tag regex). Both verified working this session.
- Has prompt-level heartbeat instructions in `subagents/prompt-*.md` templates.
  Those instructions are ignored by the model under sustained tool-call load —
  this session's data demonstrates it.

The practical next step discussed with the user: decompose long phases
(planning-initial, executing) into bounded micro-step dispatches (60–180 s
each) with state handoff via an artifacts-dir scratch file. See the session
transcript for the detailed prompt written for the fix-implementer.
